package com.wdtpr.augus.bjprofile.bjDemo;

/**
 * Created by augus on 2017/12/2.
 */

public interface IBasePresenter {
    void unsubscribe();
}
