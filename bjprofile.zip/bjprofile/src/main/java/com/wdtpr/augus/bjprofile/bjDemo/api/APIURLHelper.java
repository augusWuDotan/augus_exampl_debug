package com.wdtpr.augus.bjprofile.bjDemo.api;

/**
 * Created by augus on 2017/12/2.
 */

public class APIURLHelper {

    public static final String DOMAIN = "http://api.mosaandnasa.com.cn/";

    public static final String TEST_DOMAIN = "http://api.mosaandnasa.com.cn/";
}
