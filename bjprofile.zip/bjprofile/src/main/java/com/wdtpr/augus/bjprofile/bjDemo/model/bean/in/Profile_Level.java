package com.wdtpr.augus.bjprofile.bjDemo.model.bean.in;

import com.wdtpr.augus.bjprofile.R;

/**
 * Created by augus on 2017/12/25.
 */

public class Profile_Level {
    public final static int grayRid = R.drawable.irs_gray;
    public final static int redRid = R.drawable.irs_red;
    public final static int yellowRid = R.drawable.irs_yellow;
    public final static int greenRid = R.drawable.irs_green;

    public final static String gray = "gray";
    public final static String red = "red";
    public final static String yellow = "yellow";
    public final static String green = "green";
}
