package com.wdtpr.augus.bjprofile.bjDemo;

/**
 * Created by augus on 2017/12/13.
 */

public class BasePresenter {
}
