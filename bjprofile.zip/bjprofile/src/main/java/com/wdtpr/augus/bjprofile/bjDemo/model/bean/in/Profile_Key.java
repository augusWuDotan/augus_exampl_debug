package com.wdtpr.augus.bjprofile.bjDemo.model.bean.in;

/**
 * Created by augus on 2017/12/26.
 */

public enum Profile_Key {
    IRS,MOVIE,TEST,SPEAK,SPELL
}
