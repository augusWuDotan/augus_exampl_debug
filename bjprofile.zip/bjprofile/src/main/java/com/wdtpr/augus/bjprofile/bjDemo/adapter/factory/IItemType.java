package com.wdtpr.augus.bjprofile.bjDemo.adapter.factory;

/**
 * Created by Ray on 2017/8/14.
 * 每個Model都必須實作
 * itemType : 回傳layout佈局
 */

public interface IItemType {
    int itemType();
}
